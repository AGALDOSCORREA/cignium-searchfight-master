﻿namespace Cignium.SearchFight.Services.Models

{
    public class WebPages
    {
        public string TotalEstimatedMatches { get; set; }
    }
}
