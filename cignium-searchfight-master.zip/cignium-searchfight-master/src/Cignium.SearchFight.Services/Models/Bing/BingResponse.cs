﻿namespace Cignium.SearchFight.Services.Models

{
    public class BingResponse
    {
        public WebPages WebPages { get; set; }
    }
}